# face-detection-opencv-js


To test this copy or clone all the files with same directory structure and serve from the directory where 'index.html' file is located.

e.g:

$ python -m http.server
