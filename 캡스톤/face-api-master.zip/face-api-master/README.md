# Face-Api
To detect the face and expressions with face api.

![](face-giphy.gif)

# Face-api link
* **https://github.com/justadudewhohacks/face-api.js/blob/master/README.md**
